//1.1//
let p = document.querySelectorAll('ul > li');
p[0].after(p[2]);
p[3].before(p[1]);

//1.2//
let ul = document.getElementsByTagName('ul');
let p5 = '<li class="menu-item">Пятый пункт</li>';
let li = document.createElement('li');
li.classList.add('menu-item');
li.classContent = 'Пятый пункт';
ul[0].insertAdjacentHTML('beforeend', p5);

//2//
document.body.style.background = 'url(../dz1/img/apple_true.jpg)';

//3//
let column = document.getElementsByClassName('column');
let title = document.getElementById('title');
let text = document.createTextNode('Мы продаем только подлинную технику Apple');
column[1].removeChild(title);
column[1].insertAdjacentHTML('afterBegin', '<div class="title" id="title"> Мы продаем только подлинную технику Apple</div>');

//4//
let delete1 = document.getElementsByClassName('adv');
delete1[0].remove();

//5//
let prompt1 = document.getElementById('prompt');
let prompt2 = prompt('Какое ваше отношение к технике Apple?', '');
prompt1.textContent = prompt2;
