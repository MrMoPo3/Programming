//1//
let byId = document.getElementById('open-btn');
//console.log(byId);

//2//
let leftMenu1 = document.getElementsByClassName('name-value')[0];
let leftMenu2 = document.getElementsByClassName('budget-value')[0];
let leftMenu3 = document.getElementsByClassName('goods-value')[0];
let leftMenu4 = document.getElementsByClassName('items-value')[0];
let leftMenu5 = document.getElementsByClassName('employers-value')[0];
let leftMenu6 = document.getElementsByClassName('discount-value')[0];
let leftMenu7 = document.getElementsByClassName('isopen-value')[0];
//console.log(leftMenu1);
//console.log(leftMenu2);
//console.log(leftMenu3);
//console.log(leftMenu4);
//console.log(leftMenu5);
//console.log(leftMenu6);
//console.log(leftMenu7);

//3//
let goodsItem = document.getElementsByClassName('goods-item');
//console.log(goodsItem);

//4//
let button = document.getElementsByTagName('button');
let goodsBtn = button[1];
let budgetBtn = button[2];
let employersBtn = button[3];
//console.log(goodsBtn);
//console.log(budgetBtn);
//console.log(employersBtn);

//5//
let chooseItem = document.querySelector('.choose-item');
//console.log(chooseItem);
let timeValue = document.querySelector('.time-value');
//console.log(timeValue);
let countBudgetValue = document.querySelector('.count-budget-value');
//console.log(countBudgetValue);

//6//
let hireEmployersItem = document.querySelectorAll('.hire-employers-item');
//console.log(hireEmployersItem);





var budget, nazva, time, price;
var mainList = {
	budget,
	nazva,
	shopGoods: [],
	employers: [],
	open: false,
	discount: false,
	shopItems: [],
	start: function start(){
		nazva = prompt('Название Вашего магазина?', );
		leftMenu1.textContent = nazva;
		budgetBtn.addEventListener("click",
			function(){
				leftMenu2.textContent = countBudgetValue.value/30;
			});
		},
	Goods: function Goods(){
		for (let i = 0; i < goodsItem.length; i++){
			if(typeof(goodsItem[i].value) != null && goodsItem[i].value != '' && i > 0)
				leftMenu3.textContent = leftMenu3.textContent + ', ';
			if(typeof(goodsItem[i].value) != null && goodsItem[i].value != '')
				leftMenu3.textContent = leftMenu3.textContent + goodsItem[i].value;
		}
	},
	employersAdding: function employersAdding(){
			for (let i = 0; i < hireEmployersItem.length; i++){
			if(typeof(hireEmployersItem[i].value) != null && hireEmployersItem[i].value != '' && i > 0)
				leftMenu5.textContent = leftMenu5.textContent + ', ';
			if(typeof(hireEmployersItem[i].value) != null && hireEmployersItem[i].value != '')
				leftMenu5.textContent = leftMenu5.textContent + hireEmployersItem[i].value;
		}
	},
	worktime: function worktime(time){
		time = timeValue.value;
		if (time > 8 && time <20){
			leftMenu7.style.background = 'green';
		}
	},
	discount: function discount(time){
		if (time = 14){
			leftMenu6.style.background = 'green';
		}
		/*if (dicount = true){
			price = 0.8 * price; 
		}*/
	},
	/*WriteInDocument: function WriteInDocument(){
			document.write('Наш магазин включает в себя:<br>');

			for (i in mainList) {
			  document.write(i + " = " + mainList[i] + '<br>');
			}
		},*/
	shopItems: function shopItems(){
		products = chooseItem.value.split(",");
		products.sort();
		leftMenu4.textContent = products;
	},
};
mainList.start();

goodsBtn.addEventListener("click",
	function(){
		leftMenu3.innerText = '';
		mainList.Goods();
});

chooseItem.addEventListener("blur",
	function(){
		mainList.shopItems()
});

timeValue.addEventListener("blur",
	function(){
		mainList.worktime(time);
		mainList.discount(time);
});

employersBtn.addEventListener("click",
	function(){
		leftMenu5.innerText = '';
		mainList.employersAdding();
});