//1//
let byId = document.getElementById('open-btn');
//console.log(byId);

//2//
let leftMenu1 = document.getElementsByClassName('name-value');
let leftMenu2 = document.getElementsByClassName('budget-value');
let leftMenu3 = document.getElementsByClassName('goods-value');
let leftMenu4 = document.getElementsByClassName('items-value');
let leftMenu5 = document.getElementsByClassName('employers-value');
let leftMenu6 = document.getElementsByClassName('discount-value');
let leftMenu7 = document.getElementsByClassName('isopen-value');
/*console.log(leftMenu1);
console.log(leftMenu2);
console.log(leftMenu3);
console.log(leftMenu4);
console.log(leftMenu5);
console.log(leftMenu6);
console.log(leftMenu7);*/

//3//
let goodsItem = document.getElementsByClassName('goods-item');
//console.log(goodsItem);

//4//
let button = document.getElementsByTagName('button');
let goodsBtn = button[1];
let budgetBtn = button[2];
let employersBtn = button[3];
console.log(goodsBtn);
console.log(budgetBtn);
console.log(employersBtn);

//5//
let chooseItem = document.querySelector('.choose-item');
//console.log(chooseItem);
let timeValue = document.querySelector('.time-value');
//console.log(timeValue);
let countBudgetValue = document.querySelector('.count-budget-value');
//console.log(countBudgetValue);

//6//
let hireEmployersItem = document.querySelectorAll('.hire-employers-item')
//console.log(hireEmployersItem);