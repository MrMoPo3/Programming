//1//
let byId = document.getElementById('open-btn');

//2//
let name = document.getElementsByClassName('name');
let budget = document.getElementsByClassName('budget');
let goods = document.getElementsByClassName('goods');
let items = document.getElementsByClassName('items');
let employers = document.getElementsByClassName('employers');
let discount = document.getElementsByClassName('discount');
let isopen = document.getElementsByClassName('isopen');
let nameValue = document.getElementsByClassName('name-value');
let budgetValue = document.getElementsByClassName('budget-value');
let goodsValue = document.getElementsByClassName('goods-value');
let itemsValue = document.getElementsByClassName('items-value');
let employersValue = document.getElementsByClassName('employers-value');
let discountValue = document.getElementsByClassName('discount-value');
let isopenValue = document.getElementsByClassName('isopen-value');

//3//
let goodsItem = document.getElementsByClassName('goods-item');

//4//
let button = document.getElementsByTagName('button');

//5//
let chooseItem = document.querySelector('.choose-item');
let timeValue = document.querySelector('.time-value');
let countBudgetValue = document.querySelector('.count-budget-value');

//6//
let hireEmployersItem = document.querySelectorAll('.hire-employers-item')